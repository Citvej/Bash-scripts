#!/bin/bash

ime = "auth.log"

echo "Napadi so bili iz toliko različnih IPjev: "
cat auth.log* | grep -oE "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" | sort | uniq -c | wc -l
echo "Poskusov na root geslo je bilo: "
cat auth.log* | grep "Failed password for root" | wc -l
echo "Poskusov napada s slovarjem je bilo: "
cat auth.log* | grep "invalid user" | wc -l
echo "Uporabljena uporabniška imena pri napadu:"
cat auth.log* | grep "Invalid user"  | awk -F ' ' '{print $8}' | sort | uniq
