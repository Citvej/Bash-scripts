umask 0017

mkdir projekti
cd projekti
mkdir projektA projektB projektC

setfacl -Rm u:sd1:rw projektA
setfacl -Rm u:sd2:rw projektA
setfacl -Rm u:sd3:rw projektB
setfacl -Rm u:sd4:rw projektB
setfacl -Rm u:sd2:r projektB
setfacl	-Rm u:sd5:r .
cd ..
