sudo useradd -m sd1 -p 123
sudo useradd -m sd2 -p 123
sudo useradd -m sd3 -p 123
sudo useradd -m sd4 -p 123
sudo useradd -m sd5 -p 123

sudo groupadd razvoj

sudo usermod -a -G razvoj sd1 
sudo usermod -a -G razvoj sd2
sudo usermod -a -G razvoj sd3
sudo usermod -a -G razvoj sd4
sudo usermod -a -G razvoj sd5
