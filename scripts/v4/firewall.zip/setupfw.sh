#!/bin/bash

### zazeni s sudo ###


#privzeto zavrnemo prihajajoce povezave
ufw default deny incoming
#dovolimo port 20 za ftp povezave na ipv4
ufw allow proto tcp to 0.0.0.0/0 port 20
#dovolimo port 80 za http povezave 
ufw allow proto tcp to 0.0.0.0/0 port 80
#dovolimo povezave z racunalnika z ipjem 10.10.0.36
ufw allow from 10.10.0.36
#dovolimo povezave omrežja
ufw allow from 10.20.0.0/24
#prepovemo odzive na pinge
echo 1 > /proc/sys/net/ipv4/icmp_echo_ignore_all

#omogocimo firewall
ufw enable

