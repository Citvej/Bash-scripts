#broadcast: 10.0.10.63
#address: 10.0.10.0

sudo touch /etc/netplan/eno1.yaml

echo "
network:
  version: 2
  renderer: networkd
  ethernets:
    eno1:
      addresses: [10.0.10.36/26]
      gateway4: 10.0.10.1" > /etc/netplan/eno1.yaml

sudo netplan try eno1.yaml

sudo netplan apply eno1.yaml
