#!/bin/bash

partition="asd"

function izpis (){ #izpise vse diske/particije
	sudo lsblk -f
}

function ustvari () { 
	sudo parted -s $2 mklabel gpt  
	sudo parted -s $2 mkpart primary $3 1MiB 21MiB  # naredimo 20mb particijo
	sudo parted -s $2 mkpart primary $3 21MiB 41MiB
	sudo mkfs -t $3 $21 #naredi fs tipa ki je podan kot arg3 na particiji arg2
	sudo mkfs -t $3 $22 #naredi fs tipa ki je podan kot arg3 na particiji arg3
	sudo fsck $2
}

function priklop () {
	sudo mount $2 $3
}

function pretvori () {
	sudo umount $2
	sudo mkfs -t ext3 $2
}

while test $# -gt 0; do
	case "$1" in
		-izpis*)
			izpis
			shift
			break
			;;

		-ustvari*) #primer: bash zbircni-sistem.sh -ustvari /dev/sdb ext4
			ustvari "$@" retn
			shift
			shift
			shift
			break
			;;

		-priklop*) #primer: bash zbircni-sistem.sh -priklop /dev/sdb /mount/CD
			priklop "$@" retn
			shift shift
			break
			;;

		-pretvori*)
			pretvori "$@" retn
			shift
			break
			;;
		*)
		esac
done
