#!/bin/bash

#primer zagona -> bash dev/sdb dev/sdc dev/sdd /dev/sde /dev/md0
part1=$1"1"
part2=$2"1"
part3=$3"1"
function raid(){
	
	sudo parted -s $1 mklabel gpt
	sudo parted -s $1 -- mkpart primary 1 -1
	sudo parted -s $2 mklabel gpt
	sudo parted -s $2 -- mkpart primary 1 -1
	sudo parted -s $3 mklabel gpt
	sudo parted -s $3 -- mkpart primary 1 -1
	sudo parted -s $1 set 1 raid on
	sudo parted -s $2 set 1 raid on
	sudo parted -s $3 set 1 raid on
	sudo mdadm --create --verbose /dev/md1 --level=5 --raid-devices=2 --spare-devices=1 $part1 $part2 $part3

}

function hotspare(){
	hotspare=$1"1"
	sudo parted -s $1 mklabel gpt
	sudo parted -s $1 -- mkpart primary 1 -1
	sudo parted -s $1 set 1 raid on
	sudo mdadm --manage $5 --add $hotspare
}

read -p "Ustvarjanje raid polja (press to continue) " -n 1 -r
echo
if [[ ! REPLY =~ ^[Yy]$ ]]
then
	raid $@
fi

read -p "Dodajanje hotspare (press to continue) " -n 1 -r
echo
if [[ ! REPLY =~ ^[Yy]$ ]]
then
	echo y
	#hotspare $4
fi

read -p "Preverjanje stanja (press to continue) " -n 1 -r
echo
if [[ ! REPLY =~ ^[Yy]$ ]]
then
	cat /proc/mdstat
fi

read -p "Simuliranje izpada particije (press to continue)" -n 1 -r
echo
if [[ ! REPLY =~ ^[Yy]$ ]]
then
	sudo mdadm --manage $5 --fail $part2
fi

read -p "Odstranjevanje particije (press to continue)" -n 1 -r
echo
if [[ ! REPLY =~ ^[Yy]$ ]]
then
	sudo mdadm --manage $5 --remove $part2
fi

