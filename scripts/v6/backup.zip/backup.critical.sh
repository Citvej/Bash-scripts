#!/bin/bash

sudo ls /home/ -l | awk -F ' ' '{print "/home/"$9"/Maildir"}' > argumenti.txt
sudo mkdir /mnt/backup

sudo rdiff-backup --include-filelist argumenti.txt --exclude '**' /home /mnt/backup
