sudo tar -czf backup.tbz /mnt/backup
