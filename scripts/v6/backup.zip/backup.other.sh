#!/bin/bash

sudo ls /home/ -l | awk -F ' ' '{print "/home/"$9"/Maildir"}' > argumenti.txt
sudo mkdir /mnt/backup

sudo rdiff-backup --exclude-filelist argumenti.txt  /home /mnt/backup

