#!/bin/bash

sudo docker build -t hello-world .
sudo docker run --name hello5 -d -p 8080:80 hello-world
