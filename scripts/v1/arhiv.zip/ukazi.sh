#!/bin/bash

cd /home/neven
pwd
mkdir Jevtić
echo */
cd Jevtić
touch Neven1.txt Neven.dat Neven-Jevtić.txt
echo "E1099272E1099272E1099272" | tee -a Neven1.txt Neven.dat Neven-Jevtić.txt
find . -type f -name '*.txt'
wc -c Neven.dat
cd ..
rm -r Jevtić/