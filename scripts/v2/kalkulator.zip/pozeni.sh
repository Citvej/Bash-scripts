#!/bin/bash

echo "sestevanje:"
bash kalkulator.sh matrika1.txt matrika2.txt +
echo "odstevanje:"
bash kalkulator.sh matrika1.txt matrika2.txt -
echo "mnozenje"
bash kalkulator.sh matrika1.txt matrika2.txt x
