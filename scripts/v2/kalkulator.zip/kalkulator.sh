#!/bin/bash

# 
# kot argumente podamo imena dveh datotek ter operator
#


prestej(){ ## preveri, ce se vrstice in stolpci ujemajo, da lahko sestevamo ali odstevamo
	if [ $vrstice1 == $vrstice2 ]
	then
		if [ $stolpci1 == $stolpci2 ]
		then
			return 1
		fi
	fi

	return -1
}

sestevanje(){ # sesteje matriko
	prestej $1 $2 # najprej preveri, ce so dimenzije ustrezne
	if [ $? -eq -1  ] # ce niso potem exitaj
	then
		exit 1
	fi
	
	i=0
	while read mat1 # bere skozi prvo datoteko
	do
		final=""
		while read mat2 #bere skozi drugo datoteko in sesteva elemente
		do
			final+="$((${m1[$i]} + ${m2[$i]})) " #sem se shranjuje vrstica matrike
			i=$i+1
		done < $2
		echo $final >> "output.txt" $'\n' # zapisuje vrstice v output.txt
	done < $1
}

odstevanje(){  # enako kot sestevanje()
	prestej $1 $2
	if [ $? -eq -1  ]
	then
		exit -1
	fi
	
	i=0
	while read mat1
	do
		final=""
		while read mat2
		do
			final+="$((${m1[$i]} - ${m2[$i]})) "
			i=$i+1
		done < $2
		echo $final >> "output.txt" $'\n'	
	done < $1
}



mnozenje(){ 
	if [ $stolpci1 != $vrstice2  ] # preverimo ce sta matriki ustreznih dimenzij
	then
		echo "Matrik ni mogoce zmnoziti"
		exit -1
	fi

	declare -A arr1 # deklariramo asociativni array, ki deluje kot 2d array
	declare -A arr2

	# napolnimo 1d arraye v 2d
	k=0
	for (( i=0; i<$stolpci1; i++ ))
	do
		for (( j=0; j<$vrstice1; j++ ))	
		do
			arr1[$i,$j]=${m1[$k]}
			k=`expr $k + 1`
		done
	done
	
	k=0
	
	for (( i=0; i<$stolpci2; i++ ))
	do
		for (( j=0; j<$vrstice2; j++ ))
		do
			arr2[$i,$j]=${m2[$k]}
			k=`expr $k + 1`
		done
	done
	#koncamo s polnjenjem
	vsota=0
	final=""
	for(( i=0; i<$stolpci1; i++ ))
	do
		for(( j=0; j<$stolpci2; j++ ))
		do
			for (( k=0; k<$vrstice1; k++ ))
			do
				zmnozi ${arr1[$i,$k]} ${arr2[$k,$j]}
				vsota=`expr $vsota + $?`
				
			done
		final+="$vsota "
		done
	echo $final >> "output.txt"
	final=""
	vsota=0
	done
}

zmnozi(){
	calculation=0
	for (( k=0; k<$1; k++))
	do
		calculation=$(($calculation + $2))
	done
	return $calculation
}



m1=(`cat $1`) ## preberemo prvi argument in ga pretvorimo v array
m2=(`cat $2`) ## preberemo drugi argument in ga pretvorimo v array
op=$3 ## tretji argument - operator


dolzina1=`wc -w < $1` # prestejemo stevilo elementov prvega argumenta
dolzina2=`wc -w < $2` # in se drugega

stolpci1=` cat $1 | awk '{print NF; exit}' ` #nato se dobimo stevilo stolpcev
stolpci2=` cat $2 | awk '{print NF; exit}' `

vrstice1=$(($dolzina1 / $stolpci1)) # delimo st elementov s stevilom elementov v stolpcu da dobimo dolzino vrstice
vrstice2=$(($dolzina1 / $stolpci1))

final="" > "output.txt" # izpraznimo output.txt, da lahko not ponovno shranimo rezultat

# primerjamo operator in klicemo ustrezno aritmetično operacijo/funkcijo
if [ $3 == "+" ]
then
	sestevanje $1 $2 
	cat "output.txt" #rezultat še izpišemo
fi
if [ $3 == "-" ]
then
	odstevanje $1 $2
	cat "output.txt"
fi
if [ $3 == "x" ]
then
	mnozenje $1 $2
	cat "output.txt"
fi


